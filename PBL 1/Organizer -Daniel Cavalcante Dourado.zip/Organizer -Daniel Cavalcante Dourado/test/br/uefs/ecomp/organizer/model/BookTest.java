package br.uefs.ecomp.organizer.model;

import br.uefs.ecomp.organizer.model.Chapter;
import br.uefs.ecomp.organizer.model.Book;
import java.util.Iterator;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import org.junit.Before;
import org.junit.Test;

/**
 * Testes de unidade para a classe {@link Book}
 */
public class BookTest {
    private Book book;
    private Chapter c1, c2, c3;
    
    /**
     * Este método é executado antes de cada teste de unidade (testes a seguir), 
     * e serve para inicializar objetos que são utilizados nos testes.
     */
    @Before
    public void setUp() throws Exception {
        book = new Book("Programação com Java");     
        c1 = new Chapter("Introducao", "Java e uma linguagem de programacao.");
        c2 = new Chapter("Maquina Virtual", "Java possui uma maquina virtual chamada JVM.");
        c3 = new Chapter("Objetos", "Tudo em Java é um objeto.");    
    }
   
    /**
     * Teste de unidade que verifica se os atributos de um livro são 
     * atribuídos e modificados corretamente.
     */
    @Test
    public void testBasic(){
        assertEquals("Programação com Java", book.getTitle());        
        book.setTitle("Estrutura de Dados");        
        assertEquals("Estrutura de Dados", book.getTitle());                
    }
    
    
    /**
     * Teste de unidade que verifica se o método 
     * que compara dois livros foi implementado corretamente.
     */
    @Test
    public void testEquals(){
        Book temp = new Book("Programação com Java");
        assertTrue(temp.equals(book));

        book.setTitle("Estrutura de Dados");        
        
        assertFalse(temp.equals(book));
    }
    
    /**
     * Teste de unidade que verifica se os capítulos estão sendo inseridos 
     * corretamente
     */
    @Test
    public void testInsert(){  
        
        book.addChapter(0, c2);
        book.addChapter(1, c3);
        book.addChapter(0, c1);
        
        assertEquals(c1, book.getChapter(0));
        assertEquals(c2, book.getChapter(1));
        assertEquals(c3, book.getChapter(2));
    }
    
    /**
     * Teste de unidade que verifica se um capítulo está sendo modificado corretamente
     */
    @Test
    public void testUpdate(){        
        book.addChapter(0, c1);
        book.addChapter(1, c2);
        book.addChapter(2, c3);
        
        book.updateChapter(1, "JVM", c2.getText());
                
        Chapter temp = new Chapter("JVM", c2.getText());
        assertTrue(temp.equals(book.getChapter(1)));
    }
    
    /**
     * Teste de unidade que verifica a inserção e remoção dos capítulos
     */
    @Test
    public void testDelete(){
    	book.addChapter(0, c3);
        book.addChapter(0, c2);
        book.addChapter(0, c1);
        
        assertEquals(c3, book.getChapter(2));
                        
        
        book.removeChapter(0);
        book.removeChapter(0);
        
        assertEquals(c3, book.getChapter(0));        
        book.removeChapter(0);
        
        assertNull(book.removeChapter(0));        
    }    
    
    /**
     * Teste que verifica se os capítulos estão sendo listados corretamente.
     */
    @Test
    public void testIterator(){
        book.addChapter(0, c1);
        book.addChapter(1, c2);
        book.addChapter(2, c3);
        
        Iterator it = book.chapters();
        assertTrue(it.hasNext());
        assertEquals(c1, it.next());
        
        assertTrue(it.hasNext());assertTrue(it.hasNext());
        assertEquals(c2, it.next());
        
        assertTrue(it.hasNext());assertTrue(it.hasNext());
        assertEquals(c3, it.next());
        
        assertFalse(it.hasNext());
        assertNull(it.next());
    }
}
