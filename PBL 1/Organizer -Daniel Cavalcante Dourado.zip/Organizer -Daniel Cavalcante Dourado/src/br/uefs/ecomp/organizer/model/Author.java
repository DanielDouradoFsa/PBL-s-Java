/***
Autor: Daniel Cavalcante Dourado.
Componente Curricular: MI - Programação II
Concluido em: 02/10/2018
Declaro que este código foi elaborado por mim de forma individual e não contém nenhum 
trecho de código de outro colega ou de outro autor, tais como provindos de livros e 
apostilas, e páginas ou documentos eletrônicos da Internet. Qualquer trecho de código
de outra autoria que não a minha está destacado com uma citação para o autor e a fonte
do código, e estou ciente que estes trechos não serão considerados para fins de avaliação.
*/
package br.uefs.ecomp.organizer.model;

import br.uefs.ecomp.organizer.util.MyStack;
import br.uefs.ecomp.organizer.model.Book;
import br.uefs.ecomp.organizer.model.Chapter;
import br.uefs.ecomp.organizer.util.MyLinkedList;
import java.util.Iterator;
import java.util.Objects;

/**
 *
 * @author Daniel Cavalcante Dourado
 */
public class Author {
    private String name;
    private String surname;
    private MyStack stack;
 
    public Author(String name, String surName) {
        this.stack= new MyStack();
        this.name=name;
        this.surname=surName;
    }
    /**
     * Retorna o name do autor.
     * @return name do autor.
     */
    public String getName() {
        return name;
    }
    /**
     * Altera o nome do autor, que passa a ser o do parametro.
     * @param name que substituirá o nome antigo.
     */
    public void setName(String name) {
        this.name = name;
    }
   /**
    * Retorna sobrenome do autor.
    * @return sobreNome.
    */
    public String getSurname() {
        return surname;
    }
    /**
     * Altera sobrenome do autor.
     * @param surname do autor.
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }
    /**
     * Adiciona um livro "b" ao final da pilha dos livros.
     * @param b que foi adicionado.
     */
    public void addBook(Book b) {
        stack.push(b);
    }
    /**
     * Retorna o ultimo livro que foi adicionado.
     * @return Ultimo livro adicionado.
     */
    public Book getLastBook() {
        return (Book)stack.peek();
       /*
        *Uso do conversor pois o método retorna um book, e não um object.
        */
    }
    /**'
     * Recebe o nome de um livro como parâmetro, o livro que tiver
     * título igual ao que foi recebido como parâmetro, será removido da pilha
     * de livros.
     * 
     * @param nomeParaRemocao que será removido da pilha de livros.
     */
    public void deleteBook(String nomeParaRemocao) {
        MyStack pilhaAuxiliar = new MyStack();
        Book livro; 
        while(stack.size()!=0){
            livro=(Book) stack.peek();
            if(livro.getTitle().equals(nomeParaRemocao)){
                stack.pop();
            }
            else 
                pilhaAuxiliar.push(stack.pop());
        }
        while(pilhaAuxiliar.size()!=0){
            stack.push(pilhaAuxiliar.pop());
        }
       /*
        *A pilha é desempilhada até que o livro buscado seja encontrado e excluido
        *todos os livros que foram desempilhados para que a busca fosse feita são
        *armazenados em uma lista encadeada auxiliar, para que não sejam perdidos,
        *após a exclusão, a lista vai sendo "esvaziada" ao passo que a pilha é
        *empilhada com os livros que estavam nela.
        */
    }
    /**
     * Retorna o número de livros existentes na pilha de livros.
     * @return Quantidade de livros existentes.
     */
    public Object numBooks() {
        return stack.size();
    }
    /**
     * Percorre todos o livros da pilha, removendo os livros da pilha os passando
     * para uma lista auxiliar e depois os empilhando de volta.
     * @return Iterador da lista auxiliar que contem os livros da pilha.
     */
    public Iterator books() {
        int i;
        MyLinkedList listAuxiliar= new MyLinkedList();
        while(stack.size()!=0){
            listAuxiliar.add(0, stack.pop());
        }
        for(i=0;i<listAuxiliar.size();i++){
            stack.push(listAuxiliar.get(i));
        }
        return listAuxiliar.iterator();
        /*
        É criado uma lista auxiliar, ela recebe todos os elementos contidos na pilha
        , esses elementos serão devolvidos à pilha e depois haverá um "return" com
        o iterador da lista auxiliar.
        */
    }
    /**
     * Busca entre os livros e capítulos desse livro, o conteúdo passado
     * por parâmetro.
     * @param nomeParaBuscar, nome do livro que será adicionado na lista de livros
     * encontrado.
     * @return Iterador da lista auxiliar que contém o livro com nome procurado.
     */
    public Iterator searchBookByContent(String nomeParaBuscar) {
        int i;
        Iterator it = books();
        Book livro;
        MyLinkedList list = new MyLinkedList();
        while(it.hasNext()){
            livro = (Book) it.next();
            for(i=0;i<livro.getNumChapters();i++){
                if(livro.getChapter(i).getTitle().contains(nomeParaBuscar) || livro.getChapter(i).getText().contains(nomeParaBuscar)){
                    list.add(livro);
                    break;
                }
            }
        }
        return list.iterator();
        /*
         *É utilizado o iterador para fazer a busca, dentro de laços de repetição
         *é feito uma averiguação, para saber se o conteudo buscado foi encontrado, caso
         *seja, o livro é adicionado à lista auxiliar de livros que contém o conteúdo
         *desejado..
        */
    }


    /**
     * Verifica se um objeto passado como parâmetro e o
     * titulo do capítulo são iguais.
     * @param obj que contém nome e sobrenome,que serão comparados com o da classe
     * @return True, se forem iguais, False se foram diferentes.
     */
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Author other = (Author) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        if (!Objects.equals(this.surname, other.surname)) {
            return false;
        }
        return true;
    }
}
