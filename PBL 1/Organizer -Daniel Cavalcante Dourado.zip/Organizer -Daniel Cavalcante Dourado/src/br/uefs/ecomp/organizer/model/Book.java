/***
Autor: Daniel Cavalcante Dourado.
Componente Curricular: MI - Programação II
Concluido em: 02/10/2018
Declaro que este código foi elaborado por mim de forma individual e não contém nenhum 
trecho de código de outro colega ou de outro autor, tais como provindos de livros e 
apostilas, e páginas ou documentos eletrônicos da Internet. Qualquer trecho de código
de outra autoria que não a minha está destacado com uma citação para o autor e a fonte
do código, e estou ciente que estes trechos não serão considerados para fins de avaliação.
*/
package br.uefs.ecomp.organizer.model;

import br.uefs.ecomp.organizer.util.MyLinkedList;
import java.util.Iterator;

/**
 *
 * @author Daniel Cavalcante Dourado.
 */
public class Book {
    private String title;
    private int numChapters;
    private int numPages;
    private MyLinkedList list;
    
    
    public Book(String Title){
        this.title=Title;
        this.list= new MyLinkedList();
    }
    /**
     * Retorna o título do livro.
     * @return title do livro.
     */
    public String getTitle() {
        return title;
    }
    /**
     * Altera o nome do título.
     * @param title que substituirá o antigo título.
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * Retorna o número de capítulos do livro.
     * @return numChapters do livo.
     */
    public int getNumChapters() {
        return numChapters;
    }
    /**
     * Retorna o numero de páginas do livro.
     * @return número de páginas.
     */
    public int getNumPages() {
        return numPages;
    }
    /**
     * Adiciona um capítulo ao livro, esse capítulo será adicionado
     * em uma posição específica.
     * @param pos em que o capítulo estará.
     * @param capi, capítulo que será adicionado.
     */
    public void addChapter(int pos, Chapter capi) {
        list.add(pos, capi);
        numChapters++;
    }
    /**
     * Retorna o capítulo de uma posição específica.
     * @param i, posição do capítulo.
     * @return capítulo da posição desejada.
     */
    public Chapter getChapter(int i) {
        return (Chapter)list.get(i);
    }
    /**
     * Altera o texto e o título do um capítulo em determinada posição.
     * @param pos, posição que o capítulo desejado está.
     * @param textoParaMudar, novo texto do capítulo escolhido.
     * @param text, novo texto do capítulo escolhido.
     */
    public void updateChapter(int pos, String textoParaMudar, String text) {
       Chapter c = (Chapter) list.get(pos);
       c.setText(text);
       c.setTitle(textoParaMudar);
    }
    /**
     * Remove um capítulo de uma determinada posição.
     * @param i, posição em que se encontra o livro desejado.
     * @return Objeto removido.
     */
    public Object removeChapter(int i) {
        numChapters--;
        return list.remove(i);
    }
    /**
     * Verifica se um objeto passado como parâmetro e o
     * titulo do capítulo são iguais.
     * @param other
     * @return True, se forem iguais, False se foram diferentes.
     */
    public boolean equals(Object other) {
        if(other instanceof Book){
            Book otherBook = (Book)other;
            if(title.equals(otherBook.getTitle()) )
                return true;
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }
    /**
     * Retorna o iterador da lista de capítulos.
     * @return iterador da lista de capítulos.
     */
    public Iterator chapters() {
        return list.iterator();
    }

}
