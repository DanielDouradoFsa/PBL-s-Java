/***
Autor: Daniel Cavalcante Dourado.
Componente Curricular: MI - Programação II
Concluido em: 02/10/2018
Declaro que este código foi elaborado por mim de forma individual e não contém nenhum 
trecho de código de outro colega ou de outro autor, tais como provindos de livros e 
apostilas, e páginas ou documentos eletrônicos da Internet. Qualquer trecho de código
de outra autoria que não a minha está destacado com uma citação para o autor e a fonte
do código, e estou ciente que estes trechos não serão considerados para fins de avaliação.
*/
package br.uefs.ecomp.organizer.model;


import br.uefs.ecomp.organizer.util.MyLinkedList;
import br.uefs.ecomp.organizer.model.Author;
import java.util.Iterator;

/**
 *
 * @author Daniel Cavalcante Dourado.
 */
public class System {
    private MyLinkedList listAuthor;
    public System(){
        this.listAuthor= new MyLinkedList();
    }
    /**
     * Adiciona um author ao sistema.
     * @param a1, autor que será inserido. 
     */
    void add(Author a1) {
        listAuthor.add(a1);
    }
    /**
     * Retorna o autor de uma determinada posição da lista de autores.
     * @param i, posição do autor desejado.
     * @return Autor da posição desejada.
     */
    Object get(int i) {
        return listAuthor.get(i);
    }
    /**
     * Remove um autor, da lista de autores, com base no nome e sobrenome
     * desse
     * @param name, nome do autor.
     * @param surname, sobrenome do autor.
     */
    void remove(String name, String surname) {
        Author autorAuxiliar;
        for(int i=0;i<listAuthor.size();i++){
            autorAuxiliar = (Author) listAuthor.get(i);
            if(autorAuxiliar.getName().equals(name) && autorAuxiliar.getSurname().equals(surname)){
                listAuthor.remove(i);
                break;
            }
        }
        /*
        O laço de repetição é utilizado para ir da primeira posição da lista até
        o final dela, dentro do laço é utilizado o numero dentro do "for" para 
        retornar uma posição da lista, caso o autor dessa posição possua o nome
        e sobrenome passados como paramêtro, a função remover da lista recebe a
        posição em que ele está.
        */
    }
    /**
     * Retorna um iterador da lista de autores.
     * @return Iterador da lista.
     */
    Iterator iterator() {
        return listAuthor.iterator();
    }
    /**
     * Retorna o tamanho da lista de autores, ou seja, quantos autores
     * estão cadastrados no sistema.
     * @return tamanho da lista de autores.
     */
    int size() {
       return listAuthor.size();
    }
    
}
