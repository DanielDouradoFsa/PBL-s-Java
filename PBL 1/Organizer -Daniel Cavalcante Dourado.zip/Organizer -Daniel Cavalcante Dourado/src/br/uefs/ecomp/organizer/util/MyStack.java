/***
Autor: Daniel Cavalcante Dourado.
Componente Curricular: MI - Programação II
Concluido em: 02/10/2018
Declaro que este código foi elaborado por mim de forma individual e não contém nenhum 
trecho de código de outro colega ou de outro autor, tais como provindos de livros e 
apostilas, e páginas ou documentos eletrônicos da Internet. Qualquer trecho de código
de outra autoria que não a minha está destacado com uma citação para o autor e a fonte
do código, e estou ciente que estes trechos não serão considerados para fins de avaliação.
**/
package br.uefs.ecomp.organizer.util;

/**
 * @author Daniel Cavalcante Dourado.
 */

public class MyStack implements IStack {
    private Pilha finalDaPilha;
    private Pilha pilhaVazia;
    private int tamanhoPilha;
    
    public MyStack(){
        finalDaPilha=null;
        pilhaVazia=null;
        tamanhoPilha=0;
    }
    /**
     * Adiciona um elemento à pilha.
     * @param data que será inserido.
     */
    public void push(Object data) {
        if(pilhaVazia==null){
            finalDaPilha = new Pilha(data,null);
            pilhaVazia=finalDaPilha;
            tamanhoPilha++;
        }
        else{
            finalDaPilha = new Pilha(data,finalDaPilha);
            tamanhoPilha++;
        }
    }

    /**
     * Remove o último elemento que foi inserido à lista.
     * @return 
     */
    public Object pop() {
        if(0 != tamanhoPilha){
            Object dadoTopo;
            dadoTopo=finalDaPilha.getDados();
            finalDaPilha= finalDaPilha.getProx();
            tamanhoPilha--;
            return dadoTopo;
        }
        else
           return null;
    
    }

    /**
     * Retorna o dado do ultimo elemento inserido na pilha.
     * @return dados do "nó".
     */
    public Object peek() {
        if(pilhaVazia==null)
            return null;
        else 
            return finalDaPilha.getDados();
    }

    /**
     * Retorna a quantidade de "nós" inseridos na pilha.
     * @return quantidade de "nós".
     */
    public int size() {
        return tamanhoPilha;
    }

    /**
     * Verifica se a pilha está vazia, ou seja, se nenhum elemento foi inserido.
     * @return "True" se está vazia, "False" se não está.
     */
    public boolean isEmpty() {
        return tamanhoPilha==0;
    }
    
}
