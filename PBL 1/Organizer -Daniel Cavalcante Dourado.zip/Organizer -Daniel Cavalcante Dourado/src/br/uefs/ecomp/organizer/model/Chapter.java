/***
Autor: Daniel Cavalcante Dourado.
Componente Curricular: MI - Programação II
Concluido em: 02/10/2018
Declaro que este código foi elaborado por mim de forma individual e não contém nenhum 
trecho de código de outro colega ou de outro autor, tais como provindos de livros e 
apostilas, e páginas ou documentos eletrônicos da Internet. Qualquer trecho de código
de outra autoria que não a minha está destacado com uma citação para o autor e a fonte
do código, e estou ciente que estes trechos não serão considerados para fins de avaliação.
*/
package br.uefs.ecomp.organizer.model;

/**
 *
 * @author Daniel Cavalcante Dourado.
 */
public class Chapter {
    private String title;
    private String text;
    private int numPages;

    public Chapter(String title,String text){
        this.title=title;
        this.text=text;
    }
    /**
     * Retorna o título do capítulo.
     * @return titulo do capítulo.
     */
    public String getTitle() {
        return title;
    }
    /**
     * Altera o título do capítulo.
     * @param title do capítulo.
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * Retorna o texto do capítulo.
     * @return texto do capitulo.
     */
    public String getText() {
        return text;
    }
    /**
     * Altera o texto do capítulo.
     * @param text que substituirá o antigo. 
     */
    public void setText(String text) {
        this.text = text;
    }
    /**
     * Retorna o número de páginas do arquivo.
     * @return numPages, numero de páginas.
     */
    public int getNumPages() {
        return numPages;
    }
    
    /**
     * Verifica se o objeto passado como parâmetro possui
     * titulo e texto iguais aos da classe.
     * @param comparacao, objeto com atributos que serão comparados.
     * @return True, se forem iguais, False se foram diferentes.
     */
    public boolean equals(Object comparacao) {
        if(comparacao instanceof Chapter){
            Chapter otherChapter = (Chapter)comparacao;
            if(title.equals(otherChapter.getTitle()) && text.equals(otherChapter.getText()))
                return true;
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }
}
